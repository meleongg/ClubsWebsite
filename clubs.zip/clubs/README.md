------A Title of your project------

((Tupper Clubs Website))

------A short description of what it does (3 sentences max)------

((For club presidents, the website allows you to input your club info and automatically create a club info page.))
((For students, the website allows you to sign up and register for posted clubs.))
((The website has club info pages, club upload pages, an FAQs page, a Contacts page, an account creation page, a delete account page, and a change password page.)) 

------A short summary of what you are most proud of or found most challenging ( 3 sentences max)------

((We are most proud about how much content we were able to add in a short amount of time.))
((We started out with just the birthdays lab from week 9 and worked our way up to a functional club website. ))
((The most challenging issues came from adding increasingly complex additions to our website, as the delete password and delete account gave us to most struggle and trouble.)) 

------Anything else you want to add that might help the reader understand your project------

Make sure to read all of the small text instructions when going through the website. 
They are the clearest and most helpful in helping you navigate and go through the website.

How do you use the website?
Club presidents: 
	1. Register and create a club account. 
	2. Log into your club account.
	3. You will be taken to a club upload page. Fill out your club info (club name, president, club schedules, picture, and description).
	4. Click upload at the bottom of the page. 
	5. Your club is now uploaded! 
Students interested in clubs: 
	1. Register and create a student account
	2. Log into your student account. 
	3. You will be taken to the home page, click on clubs to see the club list. 
On the club list, read about each club. If you're interested in joining the club, click the club link and click sign up on the bottom of the club page.