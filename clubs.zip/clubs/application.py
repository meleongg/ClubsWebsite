import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for, send_from_directory
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
import imghdr

from helpers import apology, login_required, validate

# TODO
#E delete account
#E when editing, allow them to edit/delete their photo
# allow them to remove club
# add confirmation message if they want to edit/remove stuff (modal y/n)
#E FAQ and page animation -> will need to use <script> tags & JS
#E loading screen



# student account?????????????!

# Configure application, recall __name__ = file name
app = Flask(__name__)

# app.config is a subclass of a dict and can be treated like a dict

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# max file size for images is 1MB
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024

# where to store the uploaded files
app.config['UPLOAD_FOLDER'] = 'uploads'

# what file extensions are accepted
app.config['UPLOAD_EXTENSIONS'] = ['.png', '.jpg', '.gif']

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///clubs.db")

DAYS = ['Sundays', 'Mondays', 'Tuesdays', 'Wednesdays', 'Thursdays', 'Fridays', 'Saturdays','TBD']

# Ensure responses aren't cached
# as in if I login and then log out, computer won't display my session again for the next user
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Register user"""
    number = db.execute(''' SELECT count(name) FROM sqlite_master WHERE type='table' AND name='clubUsers' ''')
    if number[0]['count(name)'] == 0:
        db.execute('CREATE TABLE clubUsers (userId INTEGER PRIMARY KEY, clubName TEXT NOT NULL, password TEXT NOT NULL)')

    if request.method == 'POST':
        # obtains form data

        clubName = request.form.get('clubName')
        clubName = ' '.join(clubName.split())

        password = request.form.get('password')
        confirm = request.form.get('confirmation')
        clubUsers = db.execute('SELECT clubUsers.clubName FROM clubUsers')

        if not request.form.get("clubName"):
            return apology("Must provide club name!")

        if not request.form.get("password"):
            return apology("Must provide password!")

        if not request.form.get("confirmation"):
            return apology("Must retype password!")

        # for each user, check if the desired username has been taken
        for i in range(len(clubUsers)):
            if clubUsers[i]['clubName'].upper().replace(" ", "") == clubName.upper().replace(" ", ""):
                return apology('Club name already taken!')

        # checks if the passwords match
        if password != confirm:
            return apology('Passwords do not match!')

        # checks if the password follows a certain structure
        if not validate(password):
            return apology('Password must be at least 8 letters and contain at least 1 capital letter, 1 digit, and 1 special character!')

        flash('Thank you for registering!')

        # insert new user into the database
        db.execute('INSERT INTO clubUsers (clubName, password) VALUES(?, ?)', clubName, generate_password_hash(password))
        return render_template('login.html')
    else:
        return render_template('register.html', jumbo=True)

# code taken from CS50's finance lab but altered
@app.route('/login', methods=['GET', 'POST'])
def login():
    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("clubName"):
            return apology("Must provide club name!")

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("Must provide password!")

        # Query database for username
        rows = db.execute("SELECT * FROM clubUsers WHERE clubUsers.clubName = ?", request.form.get("clubName"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["password"], request.form.get("password")):
            return apology("Invalid username and/or password!")

        # Remember which user has logged in
        session["user_id"] = rows[0]["userId"]

        flash('Logged in!')

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html", jumbo=True)

@app.route('/changePassword', methods=['GET', 'POST'])
@login_required
def changePassword():
    # tracks if password has been changed
    changed = False

    if request.method == 'POST':
        # obtain user id, and form data
        userId = session.get('user_id')
        oldPassword = request.form.get('oldPassword')
        newPassword = request.form.get('newPassword')
        confirm = request.form.get('confirmation')
        oldPassQuery = 'SELECT clubUsers.password FROM clubUsers WHERE clubUsers.userId = ?'
        oldPass = db.execute(oldPassQuery, (userId,))

        # checks if old password is entered correctly
        if not check_password_hash(oldPass[0]['password'], oldPassword):
            return apology('Incorrect Password')

        # checks if new password is typed correctly
        if newPassword != confirm:
            return apology('Passwords do not match!')

        # checks if password is of a set structure
        if not validate(newPassword):
            return apology('Password must be at least 8 letters and contain at least 1 capital letter, 1 digit, and 1 special character!')

        # update the user's password
        updatePassQuery = 'UPDATE clubUsers SET password = ? WHERE clubUsers.userId = ?'
        db.execute(updatePassQuery, (generate_password_hash(newPassword)), (userId,))
        changed = True

        flash('Password changed!')
        return redirect('/')
    else:
        return render_template('changePassword.html')


@app.route('/deleteAccount', methods=['GET', 'POST'])
@login_required
def deleteAccount():
    # tracks if password has been deleted
    deleted = False

    if request.method == 'POST':
        # obtain user id, and form data
        userId = session.get('user_id')
        currentPassword = request.form.get('password')
        confirm = request.form.get('confirmation')
        PassQuery = 'SELECT clubUsers.password FROM clubUsers WHERE clubUsers.userId = ?'
        Pass = db.execute(PassQuery, (userId,))

        # checks if password is entered correctly
        if not check_password_hash(Pass[0]['password'], currentPassword):
            return apology('Incorrect Password')

        # checks if password is confirmed
        if currentPassword != confirm:
            return apology('Passwords do not match!')

        # delete user
        db.execute('DELETE FROM clubUsers (clubName, password)VALUES(?, ?)', userId, generate_password_hash(currentPassword))
        flash('Account Deleted')
        return redirect('/')
    else:
        return render_template('deleteAccount.html')

@app.route("/logout")
def logout():
    """Log user out"""

    flash('Logged out!')
    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")

@app.route('/', methods=['GET', 'POST'])
@login_required
def index():

    userId = session.get('user_id')
    # check if the owner already has a club associated with their account
    clubs = db.execute('SELECT clubs.name, clubs.president, clubs.description, clubs.days FROM clubs WHERE clubs.owner = ?', userId)

    number = db.execute(''' SELECT count(name) FROM sqlite_master WHERE type='table' AND name='clubs' ''')
    if number[0]['count(name)'] == 0:
        db.execute('CREATE TABLE clubs (club_id INTEGER PRIMARY KEY, owner INTEGER NOT NULL, name TEXT NOT NULL, president TEXT NOT NULL, description TEXT NOT NULL, days TEXT NOT NULL)')

    if request.method == 'POST':
        # defend against space in btwn words (allow only 1 space in btwn words)
        clubName = request.form.get('clubName')
        clubName = ' '.join(clubName.split())

        prezName = request.form.get('presidentName')
        prezName = ' '.join(prezName.split())

        clubDesc = request.form.get('clubDesc')

        selectedDays = []

        clubNames = db.execute('SELECT clubs.name FROM clubs')

        # remove ALL the spaces instead when checking e.g. tupperCouncil vs tupper council

        for i in range(len(DAYS)):
            if not request.form.get(DAYS[i]) == None:
                # Checkbox was selected
                selectedDays.append(DAYS[i])

        if len(selectedDays) == 0:
            return apology('Please select at least one day!')

        dayStr = ''
        for i in range(len(selectedDays)):
            dayStr += (selectedDays[i])
            if i != len(selectedDays) - 1:
                dayStr += ', '

        # if user has not created a club yet
        if clubs == []:
            for i in range(len(clubNames)):
                if clubNames[i]['name'].upper().replace(" ", "") == clubName.upper().replace(" ", ""):
                    return apology('Club Name already registered!')

            db.execute('INSERT INTO clubs (name, owner, president, description, days) VALUES(?,?,?,?,?)', clubName, userId, prezName, clubDesc, dayStr)
            flash('Thank you for registering your club!')
        else:
            updateClubQuery = 'UPDATE clubs SET name = ?, president = ?, description = ?, days = ? WHERE clubs.owner = ?'
            updateClub = db.execute(updateClubQuery, (clubName,), (prezName,), (clubDesc,), (dayStr,), userId)
            flash('Club info updated!')
        # problem solving

        # select the file and print its contents
        # see if I can create another sql table and store the photos
        # other wise see if i can save the photos on to the photos folder in the ide

        # selects the uploaded file
        file = request.files['img']

        # makes sure the filename is safe
        filename = secure_filename(file.filename)

        # if filename exists
        if filename != '':
            # take file extension
            file_ext = os.path.splitext(filename)[1]
            # check if the file extension is valid
            if file_ext not in app.config['UPLOAD_EXTENSIONS'] or file_ext != validate_image(file.stream):
                return apology('File type not accepted!')
            # save the file to the photos directory
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], str(session.get('user_id')) + '.' + filename[-3:]))

        return redirect(url_for('index'))

    else:
        if clubs == []:

            return render_template('index.html', days=DAYS)

        else:
            club = {}
            club['name'] = clubs[0]['name']
            club['prez'] = clubs[0]['president']
            club['desc'] = clubs[0]['description']
            club['days'] = clubs[0]['days']

            return render_template('home.html', club=club, days=DAYS)
            # pull up the users current page to show them what it currently looks like
            # by querying clubs database w/ the owner and displaying the relevant data
            # maybe shrink it to half the page and allow users to submit another form
            # with updated data ?
            # submit the form and update the database
            # allow users to edit their info
            # return render_template('home.html', days=DAYS), if edit form path -> /edit to render edit.html

@app.route('/clubs')
@login_required
def listClubs():
    clubs = db.execute('SELECT clubs.name, clubs.president FROM clubs')

    return render_template('clubs.html', clubs=clubs)

@app.route('/clubs/<club>')
@login_required
def showClub(club):
    files = os.listdir(app.config['UPLOAD_FOLDER'])

    photo = None

    # query the db for item and assign it item
    findClub = db.execute('SELECT * FROM clubs WHERE clubs.name = ?', club)

    # use club id
    extensions = ['.png', '.jpg', '.gif']

    for file in files:
        # if the file name == club id
        for i in range(len(extensions)):
            # only prints the current club's (logged in) photo
            if file == str(findClub[0]['owner']) + extensions[i]:
                photo = file
                print(photo)

    # store club info in a dict
    details = {}
    details['name'] = findClub[0]['name']
    details['prez'] = findClub[0]['president']
    details['desc'] = findClub[0]['description']
    details['days'] = findClub[0]['days']

    # pass the item to template
    if photo:
        return render_template('club.html', details=details, file=photo)
    else:
        return render_template('club.html', details=details)

@app.route('/faq')
def faq():
    return render_template('faq.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/uploads/<filename>')
@login_required
def upload(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.errorhandler(413)
def too_large(e):
    return apology('File is too large!')


def validate_image(stream):
    header = stream.read(512)
    stream.seek(0)
    format = imghdr.what(None, header)
    if not format:
        return None
    return '.' + (format if format != 'jpeg' else 'jpg')